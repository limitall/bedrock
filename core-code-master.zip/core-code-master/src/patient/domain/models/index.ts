export * from './patient.aggregate';
export * from './patient.snapshot-repository';