export class PatientUpdateDto {
    id: string;
    name?: string;
    email?: string;
    status?: boolean;
}