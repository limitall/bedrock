export class PatientStatusChangeDto {
    id: string;
    status: boolean;
}