export const services = {
    PATIENT_SRV: `PATIENT_SRV`,
} as const
