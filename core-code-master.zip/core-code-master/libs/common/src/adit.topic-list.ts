export const topicNames = {
    PATIENT_SRV__PATIENT_CREATED: `PatientCreated`,
} as const