export const featurs = {
    PATIENT_SRV__PATIENT: `patient`,
} as const