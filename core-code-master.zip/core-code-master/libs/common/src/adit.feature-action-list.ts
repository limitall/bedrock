export const featureActions = {
    CREATE: `Create`,
} as const
