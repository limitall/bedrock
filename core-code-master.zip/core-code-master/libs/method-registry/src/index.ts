export * from './method-registry';
