export type registerEventSerializerHelperType = {
    store: object;
    target: any;
};