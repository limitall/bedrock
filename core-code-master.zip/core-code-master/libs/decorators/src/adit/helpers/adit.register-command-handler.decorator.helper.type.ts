export type registerCommandHandlerHelperType = {
    store: object;
    target: any;
};