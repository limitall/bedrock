export type registerQueryHandlerHelperType = {
    store: object;
    target: any;
};