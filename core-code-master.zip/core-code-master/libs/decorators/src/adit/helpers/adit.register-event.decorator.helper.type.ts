export type registerEventHelperType = {
    store: object;
    target: any;
};