export type registerEventSubscriberHelperType = {
    store: object;
    target: any;
};