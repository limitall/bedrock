export type registerRepositoryHelperType = {
    store: object;
    target: any;
};