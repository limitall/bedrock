export type registerSnapshotRepositoryHelperType = {
    store: object;
    target: any;
};